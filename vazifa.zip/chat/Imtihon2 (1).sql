-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 12, 2026 at 06:49 PM
-- Server version: 8.0.30
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Imtihon2`
--

-- --------------------------------------------------------

--
-- Table structure for table `informations`
--

CREATE TABLE `informations` (
  `id` int NOT NULL,
  `message` text NOT NULL,
  `users_id` json NOT NULL,
  `file` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `informations`
--

INSERT INTO `informations` (`id`, `message`, `users_id`, `file`) VALUES
(1, 'lsbvjfbhvdj', '[\"5\"]', NULL),
(2, 'lsbvjfbhvdj', '[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\", \"8\", \"9\", \"10\"]', NULL),
(3, 'lsbvjfbhvdj', '[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\", \"8\", \"9\", \"10\"]', NULL),
(4, 'aaaaa', '[\"1\", \"2\", \"3\", \"4\", \"6\", \"8\", \"9\"]', NULL),
(5, 'd', '[\"1\", \"2\", \"8\"]', NULL),
(6, 'd', '[\"1\", \"2\", \"8\"]', NULL),
(7, 'd', '[\"1\", \"2\", \"8\"]', NULL),
(8, 'ksjdnvksjf', '[\"1\", \"2\", \"8\"]', NULL),
(9, 'ksjdnvksjf', '[\"1\", \"2\", \"8\"]', NULL),
(10, 'ksjdnvksjf', '[\"1\", \"2\", \"8\"]', NULL),
(11, 'g', '[\"1\", \"2\", \"3\", \"4\", \"6\", \"8\", \"9\"]', NULL),
(12, 'a', '[\"1\", \"2\", \"3\", \"4\", \"6\", \"8\", \"9\"]', NULL),
(13, 'a', '[\"1\", \"2\", \"3\", \"4\", \"6\", \"8\", \"9\"]', NULL),
(14, 'a', '[\"1\", \"2\", \"3\", \"4\", \"6\", \"8\", \"9\"]', NULL),
(15, 'a', '[\"1\", \"2\", \"3\", \"4\", \"6\", \"8\", \"9\"]', NULL),
(16, 'a', '[\"1\", \"2\", \"3\", \"4\", \"6\", \"8\", \"9\"]', NULL),
(17, 'a', '[\"1\", \"2\", \"3\", \"4\", \"6\", \"8\", \"9\"]', NULL),
(18, 'a', '[\"1\", \"2\", \"3\", \"4\", \"6\", \"8\", \"9\"]', 'C:\\Xojiakmal\\Dasturlash\\OSPanel\\domains\\Xdasturlash\\XPHP\\functions\\No-11\\type_1\\resouces\\Imtihon2.sql'),
(19, 'a', '[\"1\", \"2\", \"3\", \"4\", \"6\", \"8\", \"9\"]', 'C:\\Xojiakmal\\Dasturlash\\OSPanel\\domains\\Xdasturlash\\XPHP\\functions\\No-11\\type_1\\resouces\\Imtihon2.sql'),
(20, 'a', '[\"1\", \"2\", \"3\", \"4\", \"6\", \"8\", \"9\"]', 'C:\\Xojiakmal\\Dasturlash\\OSPanel\\domains\\Xdasturlash\\XPHP\\functions\\No-11\\type_1\\resouces\\Imtihon2.sql'),
(21, 'a', '[\"1\", \"2\", \"3\", \"4\", \"6\", \"8\", \"9\"]', '/XPHP/functions/No-11/type_1/index.php..\\resouces\\Imtihon2.sql'),
(22, 'a', '[\"1\", \"2\", \"3\", \"4\", \"6\", \"8\", \"9\"]', '/XPHP/functions/No-11/type_1/index.php..\\resouces\\Imtihon2.sql');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` int NOT NULL,
  `text` text NOT NULL,
  `file` text,
  `user_id` int NOT NULL,
  `to_whom` text NOT NULL,
  `reply` json DEFAULT NULL,
  `create_ad` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`id`, `text`, `file`, `user_id`, `to_whom`, `reply`, `create_ad`, `update_at`) VALUES
(1, 'salom', NULL, 4, '2', NULL, '2026-02-12 15:47:25', '2026-02-12 18:47:25');

-- --------------------------------------------------------

--
-- Table structure for table `send_data`
--

CREATE TABLE `send_data` (
  `id` int NOT NULL,
  `message_id` int NOT NULL,
  `send_time` datetime NOT NULL,
  `sended` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` text NOT NULL,
  `yosh` int NOT NULL,
  `tel` varchar(14) NOT NULL,
  `millat` text NOT NULL,
  `jins` text NOT NULL,
  `other` json NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `yosh`, `tel`, `millat`, `jins`, `other`) VALUES
(1, 'Ali', 16, '+998901112233', 'Uzbek', 'Erkak', '{\"mfy\": \"Yoshlik\", \"kocha\": \"Mustaqillik\", \"tuman\": \"Chirchiq\", \"davlat\": \"Uzbekiston\", \"viloyat\": \"Toshkent\"}'),
(2, 'Dilshod', 18, '+998933334455', 'Uzbek', 'Erkak', '{\"mfy\": \"DUstlik\", \"kocha\": \"Navbahor\", \"tuman\": \"Samarqand\", \"davlat\": \"Uzbekiston\", \"viloyat\": \"Samarqand\"}'),
(3, 'Malika', 17, '+998991234567', 'Uzbek', 'Ayol', '{\"mfy\": \"Bogbon\", \"kocha\": \"Gulzor\", \"tuman\": \"Qo‘qon\", \"davlat\": \"Uzbekiston\", \"viloyat\": \"Fargona\"}'),
(4, 'Jasmin', 19, '+998977778899', 'Tojik', 'Ayol', '{\"mfy\": \"Sharq\", \"kocha\": \"Istiqlol\", \"tuman\": \"Termiz\", \"davlat\": \"Uzbekiston\", \"viloyat\": \"Surxondaryo\"}'),
(5, 'Bekzod', 20, '+998935551122', 'Qozoq', 'Erkak', '{\"mfy\": \"Tinchlik\", \"kocha\": \"Yangi hayot\", \"tuman\": \"Nukus\", \"davlat\": \"Qozogiston\", \"viloyat\": \"Qoraqalpogiston\"}'),
(6, 'Sardor', 15, '+998909876543', 'Uzbek', 'Erkak', '{\"mfy\": \"Obod\", \"kocha\": \"Paxtakor\", \"tuman\": \"Asaka\", \"davlat\": \"Uzbekiston\", \"viloyat\": \"Andijon\"}'),
(7, 'Zarina', 18, '+998941112244', 'Qirgiz', 'Ayol', '{\"mfy\": \"Bahor\", \"kocha\": \"Lola\", \"tuman\": \"Namangan\", \"davlat\": \"Qirgiziston\", \"viloyat\": \"Namangan\"}'),
(8, 'Ali', 16, '+998901112233', 'Uzbek', 'Erkak', '{\"mfy\": \"Yoshlik\", \"kocha\": \"Mustaqillik\", \"tuman\": \"Yunusobod\", \"davlat\": \"Uzbekiston\", \"viloyat\": \"Toshkent\"}'),
(9, 'Malika', 17, '+998991234567', 'Uzbek', 'Ayol', '{\"mfy\": \"Bog‘bon\", \"kocha\": \"Gulzor\", \"tuman\": \"Buxoro\", \"davlat\": \"Uzbekiston\", \"viloyat\": \"Buxoro\"}'),
(10, 'Bekzod', 20, '+998935551122', 'Qozoq', 'Erkak', '{\"mfy\": \"Tinchlik\", \"kocha\": \"Yangi hayot\", \"tuman\": \"Urganch\", \"davlat\": \"Qozogiston\", \"viloyat\": \"Xorazm\"}');

-- --------------------------------------------------------

--
-- Table structure for table `users_affinities`
--

CREATE TABLE `users_affinities` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `groups_id` json DEFAULT NULL,
  `users_id` json DEFAULT NULL,
  `channels_id` json DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users_affinities`
--

INSERT INTO `users_affinities` (`id`, `user_id`, `groups_id`, `users_id`, `channels_id`) VALUES
(1, 2, NULL, '{\"1\": \"5\", \"2\": \"4\"}', NULL),
(2, 1, NULL, '{\"1\": \"5\"}', NULL),
(3, 3, NULL, NULL, NULL),
(4, 4, NULL, '{\"1\": \"5\", \"3\": \"2\"}', NULL),
(5, 5, NULL, '{\"3\": \"4\"}', NULL),
(6, 6, NULL, NULL, NULL),
(7, 7, NULL, NULL, NULL),
(8, 8, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `informations`
--
ALTER TABLE `informations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `send_data`
--
ALTER TABLE `send_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_affinities`
--
ALTER TABLE `users_affinities`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `informations`
--
ALTER TABLE `informations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `send_data`
--
ALTER TABLE `send_data`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `users_affinities`
--
ALTER TABLE `users_affinities`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
