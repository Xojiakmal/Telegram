<?php
$dsn = "mysql:host=localhost;dbname=Imtihon2";
$name = 'root';
$pass = '';
$pdo = new PDO($dsn, $name, $pass);