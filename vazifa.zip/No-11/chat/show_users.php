<?php
session_start();
include "texnic/conn.php";
include "functions/chek_session.php";

$my_id = chek_session('my_id', 'index.php');

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $user_affs = $pdo->prepare("SELECT users_id FROM users_affinities WHERE id=?");
    $user_affs->execute([$my_id]);
    
    $user_affs_id = $user_affs->fetch();
    if ($user_affs_id[0] !== null) {
        $user_affs_id = json_decode($user_affs_id[0], true);

        $query = "SELECT `id`, `name`, `tel` FROM `users` WHERE ";
        $son = true;
        foreach ($user_affs_id as $v) {
            if ($son) {
                $query.="`id`=? ";
                $son = false;
            }
            else {
                $query.="OR `id`=?";
            }
        }
        $user_affs = $pdo->prepare($query);
        $user_affs->execute($user_affs_id);
        $result = $user_affs->fetchAll(PDO::FETCH_ASSOC);
    }
}
elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $text = trim($_POST['text']);

    $stmt = $pdo->prepare("SELECT `id`, `name`, `tel` FROM `users` WHERE `tel` LIKE '%' :t ");
    $stmt->execute([':t' => $text]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <input type="text" name='text' placeholder="Qidiring">
        <input type="submit" value="Qidirish">
    </form>
    <div>
        <?if ($result !== null):?>
        <ul>
            <?foreach ($result as $v):?>
            <li><a href="chat_message.php?id=u-<?=$v['id']?>"><?=$v['name']?> - <?=$v['tel']?></a></li>
            <?endforeach;?>
        </ul>
        <?endif;?>
    </div>
</body>
</html>