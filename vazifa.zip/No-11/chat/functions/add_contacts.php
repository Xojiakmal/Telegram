<?php
function add_contacts($pdo, $my_id, $whom_id) {
    $writed_select_query = "SELECT `users_id` FROM `users_affinities` WHERE `user_id`=?";

    $writed_to_chek = $pdo->prepare($writed_select_query);
    $writed_to_chek->execute([$whom_id]);
    $writed_to_data = $writed_to_chek->fetch();

    $writed_from_chek = $pdo->prepare($writed_select_query);
    $writed_from_chek->execute([$my_id]);
    $writed_from_data = $writed_from_chek->fetch();

    if (!empty($writed_to_data['users_id'])) {
        $writed_to_data['users_id'] = json_decode($writed_to_data['users_id'], true);

        if (!in_array($my_id, $writed_to_data['users_id'])) {
            $writed_to_data['users_id'][] = $my_id;
            $writed_to_data['users_id'] = json_encode($writed_to_data['users_id']);

        }
    }
    else {
        $writed_to_data['users_id'][] = $my_id;
        $writed_to_data['users_id'] = json_encode($writed_to_data['users_id']);
    }

    if (!empty($writed_from_data['users_id'])) {
        $writed_from_data['users_id'] = json_decode($writed_from_data['users_id'], true);
        
        if (!in_array($whom_id, $writed_from_data['users_id'])) {
            $writed_from_data['users_id'][] = $whom_id;
            $writed_from_data['users_id'] = json_encode($writed_from_data['users_id']);
        }
    }
    else {
        $writed_from_data['users_id'][] = $whom_id;
        $writed_from_data['users_id'] = json_encode($writed_from_data['users_id']);
    }
    $change_query = "UPDATE `users_affinities` SET `users_id`=:f WHERE `user_id`=:s";

    $change_from_data = $pdo->prepare($change_query);
    $change_from_data->execute([':f'=>$writed_to_data['users_id'], ':s'=>$whom_id]);

    $change_to_data = $pdo->prepare($change_query);
    $change_to_data->execute([':f'=>$writed_from_data['users_id'], ':s'=>$my_id]);
}