<?php
session_start();
include 'texnic/conn.php';
include "functions/chek_session.php";
include 'functions/add_contacts.php';

$my_id = chek_session('my_id', 'index.php');

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    $_SESSION['whom'] = $_GET['id'];
    $whom_id = $_GET['id'];
    $whom_id = explode('-', $whom_id);

    if ($whom_id[0] == 'u') {
        $whom_id = $whom_id[1];
        $stmt = $pdo->prepare("SELECT `name` FROM `users` WHERE `id`=?");
        $stmt->execute([$whom_id]);
        $res = $stmt->fetch();
        
        add_contacts($pdo, $my_id, $whom_id);
    }
    elseif ($whom_id[0] == 'g') {
        $whom_id = $whom_id[1];
        $stmt = $pdo->prepare("SELECT `group_name` FROM `groups` WHERE `id`=?");
        $stmt->execute([$whom_id]);
        $res = $stmt->fetch();
        
        add_contacts($pdo, $my_id, $whom_id);
    }
}
elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $whom_id = $_SESSION['whom'];
    if(isset($_POST['textarea']) and !empty($_POST['textarea'])){
        $textarea = $_POST['textarea'];
        header("Location: send_message.php?from=u-$my_id&to=u-$whom_id&text=$textarea");
        exit;
    }
    else {
        $_SESSION['file'] = $_FILES['file'];
        header("Location:send_message.php?from=u-$my_id&to=u-$whom_id&file=true");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1><?=$res['name']?></h1>
    <form action="" method='POST' enctype="multipart/form-data">
        <input type="file" name="file" id="">
        <textarea name="textarea"></textarea>
        <input type="submit" value="Yuborish">
    </form>
</body>
</html>