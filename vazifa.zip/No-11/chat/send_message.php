<?php
session_start();
include "texnic/conn.php";
include "functions/chek_session.php";

chek_session('my_id', 'index.php');

if ((isset($_GET['from']) and !empty($_GET['from'])) and (isset($_GET['to']) and !empty($_GET['to']))) {
    $from_data = explode('-', $_GET['from']);
    $to_data = explode('-', $_GET['to']);
    if ($from_data[0] == 'u' and $to_data[0] == 'u') {
        if (isset($_GET['text'])) {
            $text = $_GET['text'];
            $from_id = $from_data[1];
            $to_id = $to_data[1];

            $query = "INSERT INTO notes(text, user_id, to_whom) VALUES (?, ?, ?)";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$text, $from_id, $to_id]);
        }
        elseif (isset($_GET['file'])) {
            $image_type = ['jpg', 'jpeg', 'png','web','gif'];
            $video_type = ['MP4','MKV','MOV'];
            $musiq_typy = ['audio', 'mp3'];

            $to_id = $to_data[1];
            $from_id = $from_data[1];
            $file = $_SESSION['file'];
            $file_type = explode('/', $file['type']);
            if (in_array($file_type[1], $image_type)) {
                file_put_contents('users_files/images/'.$file['name'], $file['tmp_name']);
                $file_path = 'users_files/images/'.$file['name'];
                
            }
            elseif (in_array($file_type[1], $video_type)) {
                file_put_contents('users_files/videos/'.$file['name'], $file['tmp_name']);
                $file_path = 'users_files/images/'.$file['name'];
                
            }
            elseif (in_array($file_type[1], $musiq_typy)) {
                file_put_contents('users_files/musics/'.$file['name'], $file['tmp_name']);
                $file_path = 'users_files/images/'.$file['name'];
                
            }
            else {
                file_put_contents('users_files/others/'.$file['name'], $file['tmp_name']);
                $file_path = 'users_files/images/'.$file['name'];
                
            }

            var_dump($file_path);
            if(!empty($file_path)){
                $sql = "INSERT INTO notes(file ,user_id, to_whom) VALUES(?, ?, ?)";
                $file_insert = $pdo->prepare($sql);
                if($file_insert->execute([$file_path, $from_data[0].$from_id, $to_data[0].$to_id])){
                    echo "File yuklandi";
                }
            }
        }
        header("Location: chat_message.php?id=".$to_id);
    }
}